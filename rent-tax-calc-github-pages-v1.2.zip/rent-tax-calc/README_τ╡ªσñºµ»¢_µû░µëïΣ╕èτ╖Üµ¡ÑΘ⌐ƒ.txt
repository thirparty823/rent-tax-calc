租賃稅務試算器（GitHub Pages）新手上線步驟
=====================================

一、你會用到的檔案（已幫你做好）
1. index.html          主畫面
2. app.js              計算邏輯
3. rules.js            稅務規則（方案）
4. brand.config.json   品牌切換設定（company/mao）
5. report.html         列印報告頁

二、上線前你要改的地方（可選）
1) 打開 brand.config.json
2) 找到 "mao" 區塊
   - primaryLinkUrl 改成你的 LINE 連結
3) 如果之後公司同意，再填 "company" 區塊的 logo / 網址

三、GitHub Pages 上線（完全新手版）
1) 註冊/登入 GitHub
   - 網址：https://github.com
   - 沒帳號就先按 Sign up 註冊

2) 建立一個新專案（Repository）
   - 右上角 + 號 → New repository
   - Repository name：rent-tax-calc (可自訂)
   - 選 Public（免費 GitHub Pages 方便）
   - 按 Create repository

3) 上傳檔案
   - 進入你剛建立的 repo 頁面
   - 按 "uploading an existing file"（或 Add file → Upload files）
   - 把上述 5 個檔案全部拖進去
   - 下方 Commit changes（直接按綠色按鈕）

4) 開啟 GitHub Pages
   - 在 repo 頁面上方選單點 Settings
   - 左側找到 Pages（有時在 Code and automation 區塊）
   - Source 選：Deploy from a branch
   - Branch 選：main / (root)
   - 按 Save

5) 等 1~3 分鐘
   - GitHub 會顯示你的網址（通常像：
     https://你的帳號.github.io/rent-tax-calc/ ）
   - 重新整理 Pages 頁面可看到連結

四、怎麼測試（你可以直接複製）
1) 基本頁面
   https://你的帳號.github.io/rent-tax-calc/

2) 個人品牌版（預設其實也是 mao）
   https://你的帳號.github.io/rent-tax-calc/?brand=mao

3) 公司品牌版（先看版型，內容可晚點補）
   https://你的帳號.github.io/rent-tax-calc/?brand=company

4) 預填示範（3/11 上課可直接用）
   https://你的帳號.github.io/rent-tax-calc/?brand=mao&scheme=rental_act_17&rent=25000&tenant=corp&resident=yes&mtr=20

五、之後你常用的修改方式（不會寫程式也能改）
A. 改品牌/聯絡方式：改 brand.config.json
B. 改法源連結/方案名稱：改 rules.js
C. 改頁面文字（標題/按鈕）：改 index.html

六、每次修改後怎麼更新網站
方法（最簡單）：
1) 回 GitHub repo 頁面
2) 點進要改的檔案
3) 點鉛筆圖示(Edit)
4) 修改內容
5) 下方 Commit changes
6) 等 1~2 分鐘，網站會自動更新

七、提醒（1.0版本）
1) 租賃條例§17 超過每月2萬元部分，目前先用 43% 費用率試算（你之後可再調）
2) 二代健保「自然人承租是否扣費」做成開關，預設不扣；請依健保署/公司口徑確認
3) 本工具是試算，不是核定

